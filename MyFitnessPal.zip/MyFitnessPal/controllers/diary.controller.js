const storage = new Foodstorage('foods');

const urlParams = new URLSearchParams(window.location.search);
const date = urlParams.get('date') || getCurrentDate();

function populateSection(sectionName) {
  const element = document.getElementById(sectionName);
  let dataStorage = storage.getAll(sectionName);

  // Filtar results only for target date
  dataStorage = dataStorage.filter(i => {
    return i.date === date;
  })

  for (const item of dataStorage) {
    const li = document.createElement('li');
    const name = document.createElement('a');
    const del = document.createElement('a');
    del.setAttribute('itemId', item.id);
    del.classList.add('deleteItem')
    del.innerHTML = 'X';

    name.innerHTML = item.name;
    name.href = '';
    li.appendChild(name);
    li.appendChild(del);
    element.appendChild(li);
  }
}

populateSection('breakfast');
populateSection('lunch');
populateSection('dinner');
