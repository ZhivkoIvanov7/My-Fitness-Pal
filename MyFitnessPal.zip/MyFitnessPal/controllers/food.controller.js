const storage = new ExtendedFoodStorage('store');
const foodStorage = new Foodstorage('foods');

let searchedItems = [];


const createSearchList = (item) => {
  const li = document.createElement('li');
  const span = document.createElement('span');
  span.innerHTML = item.name;
  const ancor = document.createElement('a');
  ancor.innerHTML = '+';

  ancor.onclick = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get('type')
    foodStorage.add({
      ...item,
      type,
      id: generateUUID(),
      date: getCurrentDate(),
    });

    location.href = 'diary.html'
  }

  li.appendChild(span);
  li.appendChild(ancor);

  return li;
}

document.getElementById('search-food').addEventListener("keyup", (event) => {
  const inputvalue = document.getElementById('search-food').value;
  if (inputvalue && inputvalue != '') {
    searchedItems = storage.search('name', inputvalue);
  } else {
    searchedItems = [];
  }

  document.getElementById('search-output').innerHTML = '';
  for (const item of searchedItems) {
    const docu = createSearchList(item);
    document.getElementById('search-output').appendChild(docu);
  }
});


const sendErrorMessage = (message) => {
  document.getElementById('error-message').innerHTML = message;
}

document.getElementById('createFood').onclick = (e) => {
  const name = document.getElementById('name').value;
  const calories = document.getElementById('calories').value;
  const carbs = document.getElementById('carbs').value;
  const fat = document.getElementById('fat').value;
  const protein = document.getElementById('protein').value;

  // check if there is a values
  if(!name || !calories) {
    sendErrorMessage('All values are required');
  } else {
    const existingItem = storage.get('name', name);

    if (existingItem) {
      sendErrorMessage('Item with this name already exists!');
    } else {
      storage.add({
        name,
        calories,
        carbs,
        fat,
        protein
      })
    }
  }
}